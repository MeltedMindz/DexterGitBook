# Roadmap
Discover the milestones and future plans for the Dexter project.
