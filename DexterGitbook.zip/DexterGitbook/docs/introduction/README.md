# Introduction
Learn about Dexter and its mission to revolutionize liquidity management.
