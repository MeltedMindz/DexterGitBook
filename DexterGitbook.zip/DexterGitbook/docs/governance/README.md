# Governance
Learn about the decentralized governance model and how  holders can participate.
