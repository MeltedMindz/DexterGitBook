# Features
Explore the key features of Dexter, including AI-driven liquidity management and integration with DeFi protocols.
