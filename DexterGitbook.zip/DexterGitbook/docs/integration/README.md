# Integration
See how Dexter integrates with Virtuals Protocol, Solana, EVM, and other DeFi ecosystems.
